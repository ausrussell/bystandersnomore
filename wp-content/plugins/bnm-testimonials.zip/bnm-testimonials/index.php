<?php

/*
Plugin Name: BNM Testimonials
Description: Testimonials for Bystanders No More
Version: 1.0
Author: Russell Ward
License: GPL2
*/

function debug_to_console($data)
{
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);

    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}

add_shortcode('bnmtestimonials', 'wpbnm_shortcode');

add_action('wp_enqueue_scripts', 'bnm_testimonial_assets');

add_action('admin_enqueue_scripts', 'bnm_testimonial_assets_admin');

function bnm_testimonial_assets_admin()
{
    wp_register_style('bnm-swiper', plugins_url('/css/bnm-swiper.css', __FILE__));   
    wp_enqueue_style('bnm-swiper');
}
function bnm_testimonial_assets()
{
    wp_register_style('swiper', plugins_url('/css/swiper.css', __FILE__));
    wp_register_script(
        'swiper',
        plugins_url('/js/swiper.js', __FILE__),
        array(),
        '1.0.0',
        array(
            'strategy' => 'defer'
        )
    );

    wp_register_style('bnm-swiper', plugins_url('/css/bnm-swiper.css', __FILE__));
    wp_register_script(
        'bnm-swiper',
        plugins_url('/js/bnm-swiper.js', __FILE__),
        array(),
        '1.0.0',
        array(
            'strategy' => 'defer'
        )
    );

    wp_enqueue_style('swiper');
    wp_enqueue_script('swiper');

    wp_enqueue_style('bnm-swiper');
    wp_enqueue_script('bnm-swiper');
}

function wpbnm_shortcode($atts = [], $content = "")
{
    debug_to_console("instance bnm_shortcode");
    $args = array(
        'post_type' => 'bnm_testimonial',
        'posts_per_page' => 10,
    );
    $loop = new WP_Query($args);
    $content = '<div class="swiper"><div class="swiper-wrapper bnm-swiper">';
    while ($loop->have_posts()) {
        $loop->the_post();
        $content .= '<div class="swiper-slide">';
        $content .= '<div class="bnm-testimonial_content">' . get_the_content() . '</div>';
        $content .= '<h5 class="bnm-testimonial_name">' . get_the_title() . '</h5>';

        $content .= '</div>';
    }
    $content .= '</div>';

    $content .= '<div class="swiper-pagination"></div>';
    $content .= '<div class="swiper-button-prev"></div>';
    $content .= '<div class="swiper-button-next"></div>';
    $content .= '</div>';

    return $content;
}

function bnm_custom_testimonial_post()
{
    $labels = array(
        'name' => 'Testimonials',
        'singular_name' => 'Testimonial',
        'menu_name' => 'Testimonial',
        'name_admin_bar' => 'Testimonial',
        'add_new' => 'Add New',
        'add_new_item' => 'Add New Testimonial',
        'new_item' => 'New Testimonial',
        'edit_item' => 'Edit Testimonial',
        'view_item' => 'View Testimonial',
        'all_items' => 'All Testimonials',
        'search_items' => 'Search Testimonials',
        'parent_item_colon' => 'Parent Testimonials:',
        'not_found' => 'No Testimonials found.',
        'not_found_in_trash' => 'No Testimonials found in Trash.'
    );
    register_post_type(
        'bnm_testimonial',
        array(
            'labels' => $labels,
            'public' => true,
            'has_archive' => 'testimonials',
            'rewrite' => array('slug' => 'testimonial'),
        )
    );

    flush_rewrite_rules( false );
}
add_action('init', 'bnm_custom_testimonial_post');

function bnm_testimonial_add_custom_box()
{
    $screens = ['bnm_testimonial'];
    foreach ($screens as $screen) {
        add_meta_box(
            'bnm_person_descriptor_id',                 // Unique ID
            'Person descriptor',      // Box title
            'bnm_person_descriptor_html',  // Content callback, must be of type callable
            $screen                            // Post type
        );
    }
}
add_action('add_meta_boxes', 'bnm_testimonial_add_custom_box');

function bnm_person_descriptor_html($post)
{
    $descriptor_value = get_post_meta($post->ID, '_bnm_person_descriptor_meta_key', true);
    // debug_to_console("bnm_person_descriptor_htmlpost types".var_dump(get_post_types()));
    debug_to_console("bnm_person_descriptor_html" . $descriptor_value)
        ?>
    <label for="wporg_field">Job title or other description</label>
    <div>
        <textarea class="bnm_textarea"  ><?php $descriptor_value ?></textarea>
    </div>
    <?php
}



function bnm_save_postdata( $post_id ) {
    debug_to_console("bnm_save_postdata" );
	if ( array_key_exists( '_bnm_person_descriptor_meta_key', $_POST ) ) {
        debug_to_console("after".$post_id );
		update_post_meta(
			$post_id,
			'_bnm_person_descriptor_meta_key',
			$_POST['wporg_field']
		);
	}
}

function wporg_custom( $post_id ) {
    debug_to_console("wporg_custom" );
	if ( array_key_exists( '_bnm_person_descriptor_meta_key', $_POST ) ) {
        debug_to_console("after".$post_id );
		update_post_meta(
			$post_id,
			'_bnm_person_descriptor_meta_key',
			$_POST['wporg_field']
		);
	}
}


add_action('save_post', 'wporg_custom', 10, 2);

add_action( 'save_post', 'bnm_save_postdata',999,3 );

add_action( 'save_post_bnm_testimonials', function(){debug_to_console("test bnm_save_postdata" );},999,3 );



